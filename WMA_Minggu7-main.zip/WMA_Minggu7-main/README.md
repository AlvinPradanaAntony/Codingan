# WMA_Minggu7(CRUD sqlite dan Manajemen File)

Nama : Ayunda Kusuma Wardani <br/>
NIM  : E41201809<br/>

<b>CRUD SQlite</b><br/>
<b>1. Tampilan awal</b> <br/>
<img src="https://user-images.githubusercontent.com/47249108/138538253-5f7174c6-fad8-4513-abff-07cc83480e47.jpg" width="288" height="640"><br/>
<b>2. Tampilan Tambah Data</b> <br/>
<img src="https://user-images.githubusercontent.com/47249108/138538254-39940c0d-acca-4a1a-98a6-06157e776585.jpg" width="288" height="640"><br/>
<b>3. Tampilan Detail Data</b> <br/>
<img src="https://user-images.githubusercontent.com/47249108/138538257-e296f3a2-c277-4f7b-afdb-9b51e6699eba.jpg" width="288" height="640"><br/>
<b>4. Tampilan Update Data</b> <br/>
<img src="https://user-images.githubusercontent.com/47249108/138538260-1193686a-8f36-4dd5-90e7-63ccb99a833e.jpg" width="288" height="640"><br/>
<b>5. Tampilan Hapus Data dengan geser ke ke kiri tiap item</b> <br/>
<img src="https://user-images.githubusercontent.com/47249108/138538263-600470c3-9b9f-4297-9b60-e07735d11a22.jpg" width="288" height="640"><br/>

<b>Manajemen File Android</b><br/>
<img src="https://user-images.githubusercontent.com/47249108/138538605-f062a317-214e-4b0d-b1bd-9970468cf7ee.jpg" width="288" height="640"><br/>
<img src="https://user-images.githubusercontent.com/47249108/138538606-aedba96c-2262-4c85-8815-6f22cba3a2ff.jpg" width="288" height="640"><br/>
<img src="https://user-images.githubusercontent.com/47249108/138538604-6c944d5b-ef71-45d2-b27d-eb60bc7faa14.jpg" width="288" height="640"><br/>
<img src="https://user-images.githubusercontent.com/47249108/138538607-e917aa93-42d0-4db1-8204-179b3cd468c4.jpg" width="288" height="640"><br/>
