(function($) {
    "use strict";
    var intro_start = {
        init: function() {
            introJs().start();
        }
    };
    intro_start.init()
})(jQuery);