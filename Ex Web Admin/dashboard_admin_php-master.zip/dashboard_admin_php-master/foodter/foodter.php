<div class="footer">
    <div class="float-right">soengsouy<strong>.com</strong> Free. </div>
    <div> <strong>Copyright</strong> Soeng Souy &copy; 2020 </div>
</div>