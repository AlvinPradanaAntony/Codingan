import React from 'react';

function HighScores(props) {
    return (
        <>
            <h1>High Scores</h1>
        </>
    );
}

export default HighScores;