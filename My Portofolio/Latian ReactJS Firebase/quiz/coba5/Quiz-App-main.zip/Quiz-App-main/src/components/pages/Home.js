import React from "react";
import Videos from "../Videos";

export default function Home() {
  return <Videos />;
}
