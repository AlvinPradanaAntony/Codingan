import React from 'react'

function Label(props) {
    return (
        <div>
            
        </div>
    )
}

export default Label
