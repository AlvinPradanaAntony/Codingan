import React from 'react'


function Forgot() {
    return (
        <div>
            <h1>Forgot</h1>
        </div>
    )
}

export default Forgot
