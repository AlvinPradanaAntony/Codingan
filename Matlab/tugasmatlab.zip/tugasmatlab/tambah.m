clear; clc;
A = imread('Fotoku2.jpeg');
inputA_Selection= A ((1:400),(1:400));

B = imread('Fotoku.jpeg');
inputB_Selection= B ((1:400),(1:400));

outputC = inputA_Selection + inputB_Selection;

subplot(1,3,1), imshow(uint8(A)),title('Citra 1');
subplot(1,3,2), imshow(uint8(B)),title('Citra 2');
subplot(1,3,3), imshow(uint8(outputC)),title('Citra Penambahan');