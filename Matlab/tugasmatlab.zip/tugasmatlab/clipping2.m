F = imread('Fotoku.JPEG');
G = rgb2gray(F);
J = clipping(G);
subplot(1,2,1),imshow(F),title('Citra Asli');
subplot(1,2,2),imshow(J),title('Citra Clipping');



