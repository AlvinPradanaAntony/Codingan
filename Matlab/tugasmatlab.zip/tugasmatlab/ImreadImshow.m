I=imread('D:\book semester 5\pvc\tugasmatlab\Fotoku.JPEG');
I = rgb2gray(I);
J = clipping(I);
subplot(1,2,1),imshow(I), title('Citra Asli');
subplot(1,2,2),imshow(J), title('Citra Negatif');



