%---------------------------------
% Program latihan 1
% MATLAB Programming
% Oleh: Noga
% --------------------------------

clear all;
clc;

disp ('-----------------------------------');
disp ('Program Latihan 1');
disp ('-----------------------------------');
%
panjang = 10;
lebar = 5 ;
luas = panjang * lebar;
disp (['luas -> ' num2str(luas)]);
