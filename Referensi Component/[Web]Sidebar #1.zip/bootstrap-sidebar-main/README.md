# Bootstrap 5 - Sidebar

This is a simple Bootstrap 5 sidebar with closing event.
You can show and Hide the Sidebar.

This is a single file project, so all the code is located in the index.php file.
In the assets/img folder you can put in your own Logo.
The Style-Tag at the top of the index.php file handles the colors etc. You can change the colors there for your own theme stylingg.


## Coding-languages:

- HTML 5
- PHP
- CSS 3
- JavaScript
- Bootstrap 5 library

_______________________________________________________________________________________________________________________________________________

Checkout my [YoutubeChannel](https://www.youtube.com/c/futuric)

Checkout my [Website](https://futuric.io)

<a href="https://www.buymeacoffee.com/futuric" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-green.png" alt="Buy Me A Coffee" height="36" width="174"></a>
