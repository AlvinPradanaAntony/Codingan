<?php
	
	
	for ($a=1; $a <37 ; $a++) { 
		$b=$a+1;
		echo "Tabel 6.$b Hasil Pengujian Kode Buir Uji $a<br>";
	}
	

?>