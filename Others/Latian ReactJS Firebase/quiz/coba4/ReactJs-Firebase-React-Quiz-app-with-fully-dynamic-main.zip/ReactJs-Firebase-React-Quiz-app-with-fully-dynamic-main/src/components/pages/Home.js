import Video from "../Videos";

export default function Home() {
  return <Video />;
}
