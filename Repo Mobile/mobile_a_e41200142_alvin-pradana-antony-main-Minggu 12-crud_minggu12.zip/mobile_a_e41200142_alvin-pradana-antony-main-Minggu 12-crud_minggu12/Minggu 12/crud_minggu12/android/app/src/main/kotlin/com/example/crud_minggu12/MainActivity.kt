package com.example.crud_minggu12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
