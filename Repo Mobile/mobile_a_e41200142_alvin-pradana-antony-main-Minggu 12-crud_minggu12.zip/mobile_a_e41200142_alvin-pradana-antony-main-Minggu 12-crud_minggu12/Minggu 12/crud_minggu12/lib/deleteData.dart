import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:crud_minggu12/editdata.dart';
import 'main.dart';

class Detail extends StatefulWidget {
  final List list;
  final int index;

  Detail({required this.list, required this.index, id});
  @override
  _DetailState createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  TextEditingController controllerJudul = TextEditingController();
  TextEditingController controllerIsi = TextEditingController();

  void deleteData() {
    var url = 'http://192.168.1.3:8080/posts';
    http.delete(Uri.parse(url + widget.list[widget.index]['id'].toString()),
        body: {
          'id': widget.list[widget.index]['id'].toString()
        }).then((response) {
      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');
    });
  }

  void confirm() {
    AlertDialog alertDialog = AlertDialog(
      content: Text(
          "Are you sure want to delete'${widget.list[widget.index]['title']}'"),
      actions: [
        RaisedButton(
          child: Text(
            "OK DELETE!",
            style: new TextStyle(color: Colors.black),
          ), // Text
          color: Colors.red,
          onPressed: () {
            deleteData();
            Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) => MyApp(),
            )); // MaterialPageRoute
          },
        ), // RaisedButton
        RaisedButton(
          child: new Text("CANCEL", style: new TextStyle(color: Colors.black)),
          color: Colors.green,
          onPressed: () => Navigator.pop(context),
        ), // RaisedButton
      ], //<Widget>[]
    ); // AlertDialog
    showDialog(builder: (context) => alertDialog, context: context);
  }

  @override
  void initState() {
    controllerJudul.text = widget.list[widget.index]['title'];
    controllerIsi.text = widget.list[widget.index]['body'];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Data"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ListView(
          children: <Widget>[
            Column(
              children: [
                TextField(
                  controller: controllerJudul,
                  decoration: InputDecoration(
                      hintText: "Judul",
                      labelText: "Judul",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14.0))),
                ),
                const SizedBox(height: 10.0),
                TextField(
                  controller: controllerIsi,
                  decoration: InputDecoration(
                      hintText: "Isi",
                      labelText: "Isi",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14.0))),
                ),
                const SizedBox(height: 25.0),
                RaisedButton(
                  child: Text(
                    "Edit Data",
                    style: TextStyle(color: Colors.white),
                  ),
                  color: Colors.blueAccent,
                  elevation: 6.0,
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (BuildContext context) =>
                            EditData(list: widget.list, index: widget.index)));
                  },
                ),
                RaisedButton(
                  child: Text(
                    "Hapus Data",
                    style: TextStyle(color: Colors.white),
                  ),
                  color: Colors.red,
                  elevation: 6.0,
                  onPressed: () => confirm(),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
