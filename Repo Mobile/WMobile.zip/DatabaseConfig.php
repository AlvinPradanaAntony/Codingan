<?php
    $HostName = "localhost";
    $HostUser = "root";
    $HostPass = "";
    $DatabaseName = "user";

?>