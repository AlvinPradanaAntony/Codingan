package com.example.minggu10_moviedb__

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
